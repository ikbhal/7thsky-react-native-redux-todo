import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import {connect} from 'react-redux'
import Constants from 'expo-constants';
class CounterApp extends React.Component {
  
  render() {
    return (
      <View style={styles.container}>
        <View style={{flexDirection:'row', width:200, 
          justifyContent:'space-around'}}>
          <TouchableOpacity onPress={()=> this.props.incrementCounter()} >
            <Text style={{fontSize:20}}>Increase</Text>
          </TouchableOpacity>
          <Text style={{fontSize:20}}>{this.props.counter}</Text>
          <TouchableOpacity onPress={()=> this.props.decrementCounter()}>
            <Text style={{fontSize:20}}>Decrease</Text>
          </TouchableOpacity>

        </View>
      </View>
    );
  }
}

function mapStateToProps(state){
  return {
    counter : state.counter
  }
}

function mapDispatchToProps(dispatch){
  return {
    incrementCounter : () => dispatch({type : 'INCREASE_COUNTER'}) ,
    decrementCounter : () => dispatch({type : 'DECREASE_COUNTER'})

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CounterApp)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  }
  
});